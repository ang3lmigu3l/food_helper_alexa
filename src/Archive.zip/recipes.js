module.exports = {
    "RECIPE_EN_GB" : {
        "fish tacos": " In a nonstick pan, heat over medium high heat the oil and then add the tilapia. Season with half the lime juice, salt, cumin and southwest seasoning. Once that side is cooked, flip and season, cooking till golden. Heat a small pan over medium heat and then spray with cooking spray. Add tortilla, cooking and heating both sides. Fill tortilla with a portion of fish and then top with desired toppings."
        
        },
    "RECIPE_EN_US" : {
        "fish tacos" : " In a nonstick pan, heat over medium high heat the oil and then add the tilapia. Season with half the lime juice, salt, cumin and southwest seasoning. Once that side is cooked, flip and season, cooking till golden. Heat a small pan over medium heat and then spray with cooking spray. Add tortilla, cooking and heating both sides. Fill tortilla with a portion of fish and then top with desired toppings.",
        "tamales" : " This is how to make tamales"
    }
};